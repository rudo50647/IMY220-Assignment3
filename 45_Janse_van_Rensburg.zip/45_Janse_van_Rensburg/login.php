<?php
	// See all errors and warnings
	error_reporting(E_ALL);
	ini_set('error_reporting', E_ALL);

	// Your database details might be different
	$mysqli = mysqli_connect("localhost", "root", "", "dbuser");

	$email = isset($_POST["email"]) ? $_POST["email"] : false;
	$pass = isset($_POST["pass"]) ? $_POST["pass"] : false;	
	$submit = isset($_POST["submit"]) ? $_POST["submit"] : false;
?>

<!DOCTYPE html>
<html>
<head>
	<title>IMY 220 - Assignment 3</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css" />
	<meta charset="utf-8" />
	<meta name="author" content="Rudo Janse van Rensburg">
</head>
<body>
	<div class="container">
		<?php
		if(!$submit || $submit){
			if(isset($_POST["email"]) && isset($_POST["pass"])){
				$query = "SELECT * FROM tbusers WHERE email = '$email' AND password = '$pass'";
				$res = $mysqli->query($query);
				if($row = mysqli_fetch_array($res)){
					$user_id = $row['user_id'];
					echo 	"<table class='table table-bordered mt-3'>
								<tr>
									<td>Name</td>
									<td>" . $row['name'] . "</td>
								<tr>
								<tr>
									<td>Surname</td>
									<td>" . $row['surname'] . "</td>
								<tr>
								<tr>
									<td>Email Address</td>
									<td>" . $row['email'] . "</td>
								<tr>
								<tr>
									<td>Birthday</td>
									<td>" . $row['birthday'] . "</td>
								<tr>
							</table>";
				
					echo 	"<form enctype='multipart/form-data' method='POST' action=''>
								<div class='form-group'>
									<input type='file' class='form-control' name='picToUpload[]' id='picToUpload' multiple/><br/>
									<input type='hidden' value='".$email."' name='email'>
									<input type='hidden' value='".$pass."' name='pass'>								
									<input type='submit' class='btn btn-standard' value='Upload Image' name='submit' onSubmit='window.location.reload()' />
								</div>
						  	</form>";
						
						if(!$submit){
							echo "</div>";
							$query = "SELECT * FROM tbgallery WHERE user_id = '$user_id'";
							if($result = $mysqli->query($query)){
								echo "<h1>Image Gallery</h1>";
								echo "<div class='row imageGallery'>";
								while($row = mysqli_fetch_array($result)){
									$fileName = $row['filename'];
									?>
									<div class='col-3' style='background-image: url(gallery/<?php echo $fileName ?>)'></div>
									<?php
								}	
								echo "</div>";
							}
						}
				}
				
				
			}else{
					echo 	'<div class="alert alert-danger mt-3" role="alert">
	  							You are not registered on this site!
	  						</div>';
			}
		}else{
				echo 	'<div class="alert alert-danger mt-3" role="alert">
	  						Could not log you in
	  					</div>';
		}
		?>
		<?php
			if(isset($_POST["submit"])){
					$dir = "gallery/";
					$total = count($_FILES['picToUpload']['name']);
					for($i=0; $i < $total; $i++){
					//1.)Determine whether the file is jpg/jpeg
					//2.)Determine if the file is less than 1000000kb
						if($_FILES['picToUpload']['tmp_name'][$i] < 1000000){
							if($_FILES['picToUpload']['type'][$i] == "image/jpg" || $_FILES['picToUpload']['type'][$i] == "image/jpeg"){
								$tmp_name =  $_FILES['picToUpload']['tmp_name'][$i];
								$name = $_FILES['picToUpload']['name'][$i];
								if(move_uploaded_file($tmp_name,$dir.$name)){
									echo
									'<div class="alert alert-primary mt-3" role="alert">
										File uploaded correctly
									</div>';
									$query = "SELECT * FROM tbusers WHERE email = '".$_POST["email"]."' AND password = '".$_POST["pass"]."'";
									$result = $mysqli->query($query);
									if($row = mysqli_fetch_array($result)){
									$user_id = $row['user_id'];
									$file = $_FILES["picToUpload"]["tmp_name"][$i];
									$query = "INSERT INTO tbgallery (user_id, filename) VALUE ('$user_id','$name')";
									if(mysqli_query($mysqli, $query)){
										$query = "SELECT * FROM tbgallery WHERE user_id = '$user_id'";
											if($result = $mysqli->query($query)){
												echo "<h1>Image Gallery</h1>";
												echo "<div class='row imageGallery'>";
												while($row = mysqli_fetch_array($result)){
													$fileName = $row['filename'];
													?>
													<div class='col-3' style='background-image: url(gallery/<?php echo $fileName ?>)'></div>
													<?php
												}
												echo "</div>";
											}
										
									}else{
									echo
										'<div class="alert alert-danger mt-3" role="alert">
											Entry could not be added!
										</div>';
								}
							}else{
								'<div class="alert alert-danger mt-3" role="alert">
									File upload was unsuccessful
								</div>';
							}
						}else{
							echo
							'<div class="alert alert-danger mt-3" role="alert">
								File not of correct type
							</div>';
						}
					}else{
						echo
						'<div class="alert alert-danger mt-3" role="alert">
	  						File too large.
	  					</div>';
						}
					
					}
				}	
			}
		?>
	</div>
</body>
</html>